#ifndef PRINTDIR_H
#define PRINTDIR_H

// Prints directories recursivly
void printDirectories(const char *name, int level);

#endif // PRINTDIR_H
